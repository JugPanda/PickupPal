# Lego Brick Recognition > 2025-01-16 12:24pm
https://universe.roboflow.com/tkl-hmvhf/lego-brick-recognition-9qaxc

Provided by a Roboflow user
License: undefined

